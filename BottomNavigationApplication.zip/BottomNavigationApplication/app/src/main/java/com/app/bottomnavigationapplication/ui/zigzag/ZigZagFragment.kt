package com.app.bottomnavigationapplication.ui.zigzag

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.app.bottomnavigationapplication.R
import com.app.bottomnavigationapplication.adapter.ZigZagAdapter
import com.app.bottomnavigationapplication.databinding.FragmentZigzagBinding

class ZigZagFragment : Fragment() {

    private var _binding: FragmentZigzagBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    private lateinit var adapter: ZigZagAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val dashboardViewModel =
            ViewModelProvider(this)[ZigZagViewModel::class.java]

        _binding = FragmentZigzagBinding.inflate(inflater, container, false)

        _binding!!.rvZigzag.layoutManager = GridLayoutManager(activity,2)

        val result = arrayListOf<Int>()
        var color = R.drawable.ic_black_box

        for (i in 0..9){
            result.add(color)
            if (i%2 == 0){
                if (color == R.drawable.ic_black_box){
                    color = R.drawable.ic_white_box
                }
                else
                {
                    color = R.drawable.ic_black_box
                }
            }
        }

        adapter = ZigZagAdapter(requireContext() , result)
        _binding!!.rvZigzag.adapter = adapter


        val textView: TextView = binding.textDashboard
        dashboardViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }
        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}