package com.app.bottomnavigationapplication.ui.home

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.bottomnavigationactivity.ui.home.HomeViewModel
import com.app.bottomnavigationactivity.ui.home.ViewModelFactory
import com.app.bottomnavigationapplication.activity.MapActivity
import com.app.bottomnavigationapplication.activity.SelectedEmployees
import com.app.bottomnavigationapplication.adapter.HomeAdapter
import com.app.bottomnavigationapplication.apimodel.Data
import com.app.bottomnavigationapplication.databinding.FragmentHomeBinding
import com.app.bottomnavigationapplication.network.ApiService
import com.app.bottomnavigationapplication.repository.MainRepository

class HomeFragment : Fragment(), HomeAdapter.OnItemClick {

    private var _binding: FragmentHomeBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    private var empList = arrayListOf<Data>()
    private var list = arrayListOf<Data>()

    private lateinit var adapter: HomeAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {

        _binding = FragmentHomeBinding.inflate(layoutInflater, container, false)

        adapter = HomeAdapter(/*empList,*/ requireActivity(), this)
        _binding!!.rvHomeFragment.layoutManager = LinearLayoutManager(requireActivity())
        _binding!!.rvHomeFragment.adapter = adapter


        val repository = ApiService.getInstance()


        val homeViewModel = ViewModelProvider(
            this, ViewModelFactory(MainRepository(repository))
        )[HomeViewModel::class.java]

        homeViewModel.getEmployeeList()

        homeViewModel.employeeList.observe(viewLifecycleOwner) {
            adapter.getEmpList(it)
            empList.addAll(it)
            if (it.isNotEmpty()){
                binding.pbHomeFragment.visibility = View.GONE
            }
            Log.d("EmplList", "onCreateView: $it")
        }

            binding.btnNextHomeFragment.visibility = View.GONE

            _binding!!.btnNextHomeFragment.setOnClickListener {

                empList.filter {
                    it.isSelected
                }
                Log.w("HomeFragment", "onCreateView:  $it")
                startActivity(
                    Intent(
                        requireActivity(), SelectedEmployees::class.java
                    ).putExtra("SelectedEmployeeList", list)
                )
            }



        _binding!!.btnMapView.setOnClickListener {
            startActivity(Intent(requireActivity(), MapActivity::class.java))
        }
        return binding.root
    }

    override fun onItemClickListner(employees: Data) {

        if (!list.contains(employees)) {
            list.add(employees)
            Log.d("Remove", "onItemClickListner: $list ")
        } else {
            list.remove(employees)
        }


        if (list.isEmpty()){
            binding.btnNextHomeFragment.visibility = View.GONE
        }
        else{
            binding.btnNextHomeFragment.visibility = View.VISIBLE
        }
        Log.d("LIST", "onItemClickListner: $list")
    }

}