package com.app.bottomnavigationapplication.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.util.SparseBooleanArray
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.app.bottomnavigationapplication.R
import com.app.bottomnavigationapplication.apimodel.Data
import com.app.bottomnavigationapplication.databinding.EmployeesItemrowBinding
import com.bumptech.glide.Glide

class HomeAdapter(private val context: Context, private var selectedList: OnItemClick) :
    RecyclerView.Adapter<HomeAdapter.MyViewHolder>() {

    private var empList = mutableListOf<Data>()

    private val checkedList = SparseBooleanArray()

    @SuppressLint("NotifyDataSetChanged")
    fun getEmpList(data: ArrayList<Data>) {
        this.empList = data.toMutableList()
        notifyDataSetChanged()
    }

    class MyViewHolder(val binding: EmployeesItemrowBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(
            EmployeesItemrowBinding.inflate(
                LayoutInflater.from(context),
                parent,
                false
            )
        )

    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        val getEmployee = empList[position]

        Glide.with(context).load(getEmployee.image).into(holder.binding.imgViewEmployeeImage)
        holder.binding.tvEmployeeName.text = getEmployee.name
        holder.binding.tvTechnology.text = getEmployee.technology
        holder.binding.tvEmployeeEmail.text = getEmployee.email
        holder.binding.tvEmployeeMobile.text = getEmployee.mobileNo
        holder.binding.tvEmployeeAddress.text = getEmployee.address

        if (getEmployee.technology == "1") {
            holder.binding.tvTechnology.text = context.getString(R.string.android_developer)
        } else {
            holder.binding.tvTechnology.text = context.getText(R.string.ios_developer)
        }
        holder.binding.checkbox.isChecked = checkedList.get(position,false)

        holder.binding.checkbox.setOnClickListener {
            if (!checkedList.get(position,false)){
                holder.binding.checkbox.isChecked = true
                checkedList.put(position,true)
            }
            else
            {
                holder.binding.checkbox.isChecked =false
                checkedList.put(position,false)
//                selectedList.onItemClickListner(getEmployee)
            }
            selectedList.onItemClickListner(getEmployee)
        }

    }

    override fun getItemCount(): Int {
        return empList.size
    }

    interface OnItemClick {
        fun onItemClickListner(employees: Data)
    }

}