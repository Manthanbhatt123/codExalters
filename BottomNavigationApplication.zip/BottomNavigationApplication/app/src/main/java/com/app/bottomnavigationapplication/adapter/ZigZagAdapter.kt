package com.app.bottomnavigationapplication.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.app.bottomnavigationapplication.databinding.ZigzagItemrowBinding
import com.bumptech.glide.Glide

class ZigZagAdapter(private val context: Context ,  val color:ArrayList<Int> ):RecyclerView.Adapter<ZigZagAdapter.MyViewHolder>() {
    class MyViewHolder (val binding: ZigzagItemrowBinding):RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(ZigzagItemrowBinding.inflate(LayoutInflater.from(context),parent,false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        Glide.with(context).load(color[position]).into(holder.binding.ivZigZag)
    }

    override fun getItemCount(): Int {
        return color.size
    }
}