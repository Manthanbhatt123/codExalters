package com.app.bottomnavigationactivity.ui.home

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.app.bottomnavigationapplication.apimodel.Data
import com.app.bottomnavigationapplication.apimodel.EmployeesList
import com.app.bottomnavigationapplication.repository.MainRepository
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeViewModel(private val repository: MainRepository) : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is home Fragment"
    }
    val text: LiveData<String> = _text


    val employeeList = MutableLiveData<ArrayList<Data>>()

    fun getEmployeeList(){
        repository.getEmployeeData().enqueue(object:Callback<EmployeesList>{
            override fun onResponse(call: Call<EmployeesList>, response: Response<EmployeesList>) {
                employeeList.postValue(response.body()?.data as ArrayList<Data>)
                Log.d("Response", "onResponse: ${response.body()}  ")
                Log.d("Response", "onResponse: ${response.code()}  ")
            }

            override fun onFailure(call: Call<EmployeesList>, t: Throwable) {
                Log.d("Response", "onFailure: ${t.message}")
            }
        })
    }
}