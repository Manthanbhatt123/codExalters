package com.app.bottomnavigationapplication.activity

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.ViewModelProvider
import com.app.bottomnavigationactivity.ui.home.HomeViewModel
import com.app.bottomnavigationactivity.ui.home.ViewModelFactory
import com.app.bottomnavigationapplication.R
import com.app.bottomnavigationapplication.adapter.HomeAdapter
import com.app.bottomnavigationapplication.apimodel.Data
import com.app.bottomnavigationapplication.databinding.ActivityMapBinding
import com.app.bottomnavigationapplication.network.ApiService
import com.app.bottomnavigationapplication.repository.MainRepository
import com.bumptech.glide.Glide
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions

class MapActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var binding: ActivityMapBinding
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var currentLocation: Location
    private val permissionCode = 101
    private val repository = ApiService.getInstance()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val mFragment =supportFragmentManager.findFragmentById(R.id.fragMapView) as SupportMapFragment

        mFragment.getMapAsync(this)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        fetchLocation()
        onClick()
    }

    private fun onClick(){
        binding.btnMapBack.setOnClickListener {
            finish()
        }
    }

    private fun fetchLocation() {
        if (ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),permissionCode)
            return
        }

        val task = fusedLocationClient.lastLocation

        task.addOnSuccessListener { location ->
            if (location != null) {
                currentLocation = location
                val supportMapFragment =
                    (supportFragmentManager.findFragmentById(R.id.fragMapView) as SupportMapFragment?)
                supportMapFragment?.getMapAsync(this)
            }
        }
    }


    override fun onMapReady(googleMap: GoogleMap) {

        val homeViewModel = ViewModelProvider(
            this, ViewModelFactory(MainRepository(repository))
        )[HomeViewModel::class.java]

        homeViewModel.getEmployeeList()


        homeViewModel.employeeList.observe(this) {

            for (i in it) {

                val latLng = LatLng(i.lat.toDouble(), i.lng.toDouble())

                if (i.technology == "1") {
                    googleMap.addMarker(MarkerOptions().icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)).position(latLng))?.tag = i
                    googleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng))
                    googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,5f))
                } else {
                    googleMap.addMarker(MarkerOptions().icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)).position(latLng))?.tag = i
//                    googleMap.addMarker(MarkerOptions().icon(BitmapDescriptorFactory).position(latLng))?.tag = i
                    googleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng))
                    googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,5f))
                   }

                googleMap.setOnMarkerClickListener {
                    binding.clMapView.visibility = View.VISIBLE
                    val data:Data = it.tag as Data
                    Glide.with(this).load(data.image).into(binding.mvEmployeeImage)
                    binding.mvSelectedEmployeeName.text = data.name
                    binding.mvSelectedEmployeeTechnology.text = data.technology
                    if (binding.mvSelectedEmployeeTechnology.text =="1"){
                        binding.mvSelectedEmployeeTechnology.text = getText(R.string.android_developer)
                    }else{
                        binding.mvSelectedEmployeeTechnology.text =getText(R.string.ios_developer)
                    }
                    binding.mvTvEmployeeEmail.text = data.empId
                    binding.mvTvSelectedEmployeeEmployeeMobile.text = data.mobileNo
                    binding.mvTvSelectedEmployeeEmployeeAddress.text = data.address
                    true
                }

                googleMap.setOnMapClickListener {
                    binding.clMapView.visibility = View.GONE
                }
            }
            Log.d("EmplList", "onCreateView: $it")
        }

//        googleMap.setOnMarkerClickListener {marker:Marker   ->
//            binding.clMapView.visibility = View.VISIBLE
//            Log.d("TAG", "onMapReady: ${marker.tag}")
//            val data:Data = marker.tag as Data
//            Glide.with(this).load(data.image).into(binding.mvEmployeeImage)
//            true
//        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String?>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            permissionCode -> if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                fetchLocation()
            }
        }
    }
}

