package com.app.bottomnavigationapplication.activity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.bottomnavigationapplication.adapter.SelectedEmployeesAdapter
import com.app.bottomnavigationapplication.apimodel.Data
import com.app.bottomnavigationapplication.databinding.ActivitySelectedEmployeesBinding

class SelectedEmployees : AppCompatActivity() , SelectedEmployeesAdapter.OnClick{
    private lateinit var binding: ActivitySelectedEmployeesBinding
    private lateinit var adapter: SelectedEmployeesAdapter

    private var list = ArrayList<Data>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelectedEmployeesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        list = intent.getSerializableExtra("SelectedEmployeeList") as ArrayList<Data>
        init()
    }


    private fun init() {
        onClick()
        initAdapter()
    }
    private fun initAdapter() {
        binding.rvSelectedEmployees.layoutManager = LinearLayoutManager(this)
        adapter = SelectedEmployeesAdapter(list, this , this)
        binding.rvSelectedEmployees.adapter = adapter
        adapter.notifyDataSetChanged()
    }


    private fun onClick() {
        binding.btnBackSelectedActivity.setOnClickListener {
            finish()
        }
    }


    override fun onStop() {
        super.onStop()
        list.clear()
    }

    override fun onItemClick(employees: Data) {
        if (!employees.isSelected){
            list.remove(employees)
        }
        if (list.isEmpty()){
            finish()
        }
        adapter.notifyDataSetChanged()
    }

    override fun onBackPressed() {
        finish()
    }
}