package com.app.bottomnavigationapplication.apimodel


import com.google.gson.annotations.SerializedName

data class EmployeesList(
    @SerializedName("data")
    val `data`: List<Data>,
    @SerializedName("message")
    val message: String,
    @SerializedName("statusCode")
    val statusCode: Int
)