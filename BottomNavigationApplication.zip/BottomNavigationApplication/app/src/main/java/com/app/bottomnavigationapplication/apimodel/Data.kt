package com.app.bottomnavigationapplication.apimodel


import com.google.gson.annotations.SerializedName

data class Data(
    @SerializedName("address")
    val address: String,
    @SerializedName("emp_Id")
    val empId: String,
    @SerializedName("image")
    val image: String,
    @SerializedName("lat")
    val lat: String,
    @SerializedName("lng")
    val lng: String,
    @SerializedName("mobile_no")
    val mobileNo: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("technology")
    val technology: String,
    @SerializedName("email")
    val email:String,

    var isSelected: Boolean =  false

):java.io.Serializable