package com.app.bottomnavigationapplication.network

import com.app.bottomnavigationapplication.apimodel.EmployeesList
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

interface ApiService {
    @GET("employee/getEmployeeList.php")
    fun getEmployeeData():Call<EmployeesList>
    companion object{
        private var Instance: ApiService? = null

        fun getInstance(): ApiService {

            if (Instance == null){
                val retrofitService = Retrofit.Builder()
                    .addConverterFactory(GsonConverterFactory.create())
                    .baseUrl("http://codexalters-techlabs.com/")
                    .build()
                Instance = retrofitService.create(ApiService::class.java)
            }
            return Instance!!
        }
    }
}