package com.app.bottomnavigationapplication.repository

import com.app.bottomnavigationapplication.network.ApiService

class MainRepository(private val apiService: ApiService) {

    fun getEmployeeData() = apiService.getEmployeeData()
}