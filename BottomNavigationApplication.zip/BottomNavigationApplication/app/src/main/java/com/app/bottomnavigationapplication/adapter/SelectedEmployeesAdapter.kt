package com.app.bottomnavigationapplication.adapter

import android.content.Context
import android.util.SparseBooleanArray
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.app.bottomnavigationapplication.apimodel.Data
import com.app.bottomnavigationapplication.databinding.SelectedEmployeesItemrowBinding
import com.bumptech.glide.Glide

class SelectedEmployeesAdapter(private val arrayList: ArrayList<Data>,private val context: Context,private val selectedList: OnClick) : RecyclerView.Adapter<SelectedEmployeesAdapter.MyViewHolder>() {

    private  val checkedList = SparseBooleanArray()

    class MyViewHolder(val binding: SelectedEmployeesItemrowBinding) :RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(
            SelectedEmployeesItemrowBinding.inflate(
                LayoutInflater.from(context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        val getEmployees = arrayList[position]
        Glide.with(context).load(getEmployees.image).into(holder.binding.roundedImageView)
        holder.binding.tvSelectedEmployeeName.text = getEmployees.name
        holder.binding.tvEmployeeEmail.text = getEmployees.email
        holder.binding.tvSelectedEmployeeTechnology.text = getEmployees.technology
        holder.binding.tvSelectedEmployeeEmployeeMobile.text = getEmployees.mobileNo
        holder.binding.tvSelectedEmployeeEmployeeAddress.text = getEmployees.mobileNo

        holder.binding.cbSelectedEmployees.isChecked = checkedList.get(position,true)

        holder.binding.cbSelectedEmployees.setOnClickListener {
            if (checkedList.get(position,true)){
                holder.binding.cbSelectedEmployees.isChecked =true
                checkedList.put(position,true)
                selectedList.onItemClick(getEmployees)
            }
            else
            {
                holder.binding.cbSelectedEmployees.isChecked =false
                checkedList.put(position,false)
                selectedList.onItemClick(getEmployees)
            }
        }
    }

    override fun getItemCount(): Int {
        return arrayList.size
    }

    interface OnClick {
        fun onItemClick(employees: Data)

    }

}